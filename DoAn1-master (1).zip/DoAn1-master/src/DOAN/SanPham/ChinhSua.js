import React from 'react';

function ChinhSua() {
  return (
    <>
      <h1>Trang chinh sua</h1>
    </>
  );
}

export default ChinhSua;
